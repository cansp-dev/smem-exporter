
// smem_exporter - fixed clap short options demo

use clap::Parser;

#[derive(Parser, Debug)]
#[command(name="smem_exporter", version, about="demo")]
struct Args {
    #[arg(short='c', long)]
    config: Option<String>,

    #[arg(short='l', long)]
    listen: Option<String>,

    #[arg(long)]
    print_config: bool,

    #[arg(short='t', long, default_value_t = 30)]
    cache_ttl: u64,
}

fn main() {
    let args = Args::parse();
    println!("OK {:?}", args.cache_ttl);
}
